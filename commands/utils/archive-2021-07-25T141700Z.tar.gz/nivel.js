const Discord = require('discord.js')
const GDclient = require("node-geometry-dash")
const GD = new GDClient();

module.exports = {
      name: 'nivel',
    
      async execute(client, message, args) {
      const nivel = args.join(' ')
           if (!nivel) return message.channel.send('<a:no:859383457125236736> | `Necesitas escribir un nivel`')
           GD.levels(nivel).then( levels => { 
           console.log(levels) 
   const gdembed1 = new Discord.MessageEmbed() //un nuevo embed
   gdembed1.setTitle("<:info:861666262857285633> | Informacion del Nivel " + levels[0].name) 
   gdembed1.addField("<:user:859383433075359785> | Creador", levels[0].author.name, true)
   gdembed1.addField("<:id:867714317382320139> | Nivel ID", levels[0].id, true) 
   if (levels[0].difficulty == 'Easy') {gdembed1.addField('<:easy:867771315310034964> | Dificultad', levels[0].difficulty, true)}
   if (levels[0].difficulty == 'Normal') {gdembed1.addField('<:medium:867771315280281650> | Dificultad', levels[0].difficulty, true)}
   if (levels[0].difficulty == 'Hard') {gdembed1.addField('<:hard:867771315132825610> | DIficultad', levels[0].difficulty, true)}
   if (levels[0].difficulty == 'Harder') {gdembed1.addField('<:harder:867771314797150300> | DIficultad', levels[0].difficulty, true)}
   if (levels[0].difficulty == 'Insane') {gdembed1.addField('<:insane:867771315270975498> | Dificultad', levels[0].difficulty, true)}
   if (levels[0].difficulty == 'Demon') {gdembed1.addField('<:demon:867715478473539604> | DIficultad', levels[0].difficulty, true)}
   gdembed1.addField("<:star:867715162667483160> | Estrellas", levels[0].stars, true)
   gdembed1.addField("<:download:867715162633797652> | Descargas", levels[0].downloads, true) 
   gdembed1.addField("<a:flecha2:862704053275459594> | Duracion", levels[0].length, true) 
   gdembed1.addField("<:moneda:859383454458445824> | Coins", levels[0].coins, true)
   gdembed1.addField("<:moneda:859383454458445824> | Coins verificadas", levels[0].verifiedCoins, true) 
   gdembed1.addField("<:like:867715162630258718> | Likes", levels[0].likes, true) 
   gdembed1.setColor("RANDOM") 

  
   message.channel.send(gdembed1) 
  }).catch(e => { message.channel.send(e)})
      }
}