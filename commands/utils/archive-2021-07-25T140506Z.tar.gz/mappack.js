const Discord = require('discord.js')
const GDclient = require("node-geometry-dash")
const GD = new GDClient();

module.exports = {
    name: 'mappack',
    alias: ['mp'],
    
   async execute(client, message, args) {
        const mappack = args.join(' ')
           if (!mappack) return message.channel.send('<a:no:859383457125236736> | `Necesitas escribir el nombre de un map pack`')
           GD.mappacks(mappack).then(mappack)
           const mpembed = new Discord.MessageEmbed()
           .setTitle(`Información del map pack ${mappack}`)
           .addField('<a:dancing:859383458451554314> | Niveles', mappack[0].levels, true)
           .addFIeld('<:star:867715162667483160> | Estrellas', mappack[0].stars, true)
           .addField('<:moneda:859383454458445824> | Monedas', mappack[0].coins)
           .addField('<a:rate:867775377837785138> | Dificultad', mappack[0].difficulty)
           
           message.channel.send(mpembed).catch(() => { message.channel.send('<a:error:859383436087263242> | `Ocurrió un error`')})
    }
}