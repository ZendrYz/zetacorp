const Discord = require('discord.js')
const GDclient = require("node-geometry-dash")
const GD = new GDClient();

module.exports = {
    name: 'usuario',
    
    async execute(client, message, args) {
        let usera = args.join(' ')
           if (!usera) return message.channel.send('<a:no:859383457125236736> | `Necesitas escribir un usuario`')
           
           GD.users(usera).then(user => {
           
           const userembed = new Discord.MessageEmbed()
           .setTitle(`Información del usuario ${usera}`)
           .addField('<:moneda:859383454458445824> | Monedas', user[0].coins + user[0].userCoins, true)
           .addField('<:star:867715162667483160> | Estrellas', user[0].stars, true)
           .addField('<:demon:867715478473539604> | Demons', user[0].demons, true)
           .addField('<:cre:867768972329222204> | Creator Points', user[0].creatorPoints, true)
           .setColor('RANDOM')
           message.channel.send(userembed)
           }).catch(() => { message.channel.send('<a:error:859383436087263242> | `No se encontró el usuario`')})
    }
}